const { useState, useEffect, createContext, useContext } = React;

const API_URL = 'http://localhost:5000/api';

// Context for auth
const AuthContext = createContext();

const AuthProvider = ({ children }) => {
  const [user, setUser] = useState(null);
  const [token, setToken] = useState(localStorage.getItem('token'));

  useEffect(() => {
    if (token) {
      fetchUser();
    }
  }, [token]);

  const fetchUser = async () => {
    try {
      const res = await fetch(`${API_URL}/auth/profile`, {
        headers: { Authorization: `Bearer ${token}` }
      });
      if (res.ok) {
        const data = await res.json();
        setUser(data);
      } else {
        logout();
      }
    } catch (error) {
      console.error('Error fetching user:', error);
    }
  };

  const login = async (email, password) => {
    const res = await fetch(`${API_URL}/auth/login`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ email, password })
    });
    const data = await res.json();
    if (res.ok) {
      localStorage.setItem('token', data.token);
      setToken(data.token);
      setUser(data.user);
      return { success: true };
    }
    return { success: false, error: data.error };
  };

  const register = async (email, password, name) => {
    const res = await fetch(`${API_URL}/auth/register`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ email, password, name })
    });
    const data = await res.json();
    if (res.ok) {
      localStorage.setItem('token', data.token);
      setToken(data.token);
      setUser(data.user);
      return { success: true };
    }
    return { success: false, error: data.error };
  };

  const logout = () => {
    localStorage.removeItem('token');
    setToken(null);
    setUser(null);
  };

  return React.createElement(AuthContext.Provider, {
    value: { user, token, login, register, logout, isAuthenticated: !!token }
  }, children);
};

const useAuth = () => useContext(AuthContext);

// Login Component
const Login = () => {
  const [isLogin, setIsLogin] = useState(true);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [name, setName] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);
  const { login, register } = useAuth();

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError('');
    setLoading(true);

    try {
      const result = isLogin
        ? await login(email, password)
        : await register(email, password, name);

      if (!result.success) {
        setError(result.error);
      }
    } catch (err) {
      setError('An error occurred');
    } finally {
      setLoading(false);
    }
  };

  return React.createElement('div', { className: 'auth-form' }, [
    React.createElement('h1', { key: 'title', style: { textAlign: 'center', marginBottom: '20px', color: '#667eea' } }, '🍵 Tea Shop Billing'),
    error && React.createElement('div', { key: 'error', className: 'alert alert-error' }, error),
    React.createElement('form', { key: 'form', onSubmit: handleSubmit }, [
      !isLogin && React.createElement('div', { key: 'name', className: 'form-group' }, [
        React.createElement('label', { key: 'label' }, 'Name'),
        React.createElement('input', {
          key: 'input',
          type: 'text',
          value: name,
          onChange: (e) => setName(e.target.value),
          required: true
        })
      ]),
      React.createElement('div', { key: 'email', className: 'form-group' }, [
        React.createElement('label', { key: 'label' }, 'Email'),
        React.createElement('input', {
          key: 'input',
          type: 'email',
          value: email,
          onChange: (e) => setEmail(e.target.value),
          required: true
        })
      ]),
      React.createElement('div', { key: 'password', className: 'form-group' }, [
        React.createElement('label', { key: 'label' }, 'Password'),
        React.createElement('input', {
          key: 'input',
          type: 'password',
          value: password,
          onChange: (e) => setPassword(e.target.value),
          required: true
        })
      ]),
      React.createElement('button', {
        key: 'submit',
        type: 'submit',
        className: 'btn-primary',
        disabled: loading
      }, loading ? 'Loading...' : (isLogin ? 'Login' : 'Register'))
    ]),
    React.createElement('p', { key: 'toggle', style: { textAlign: 'center', marginTop: '15px' } }, [
      isLogin ? 'Don\'t have an account? ' : 'Already have an account? ',
      React.createElement('button', {
        type: 'button',
        onClick: () => setIsLogin(!isLogin),
        style: { background: 'none', border: 'none', color: '#667eea', cursor: 'pointer', textDecoration: 'underline' }
      }, isLogin ? 'Register' : 'Login')
    ])
  ]);
};

// Dashboard Component
const Dashboard = () => {
  const [summary, setSummary] = useState(null);
  const [todaysSummary, setTodaysSummary] = useState(null);
  const { token } = useAuth();

  useEffect(() => {
    fetchData();
  }, []);

  const fetchData = async () => {
    try {
      const [res1, res2] = await Promise.all([
        fetch(`${API_URL}/dashboard/sales-summary?days=7`, { headers: { Authorization: `Bearer ${token}` } }),
        fetch(`${API_URL}/dashboard/todays-summary`, { headers: { Authorization: `Bearer ${token}` } })
      ]);

      if (res1.ok) {
        const data = await res1.json();
        setSummary(data);
      }
      if (res2.ok) {
        const data = await res2.json();
        setTodaysSummary(data);
      }
    } catch (error) {
      console.error('Error fetching dashboard data:', error);
    }
  };

  return React.createElement('div', null, [
    React.createElement('h2', { key: 'title' }, 'Dashboard'),
    React.createElement('div', { key: 'cards', className: 'dashboard-grid' }, [
      todaysSummary && React.createElement('div', { key: 'sales', className: 'card' }, [
        React.createElement('h3', { key: 'label' }, "Today's Sales"),
        React.createElement('div', { key: 'value', className: 'value' }, `₹${todaysSummary.dailyData.totalSales.toFixed(2)}`)
      ]),
      todaysSummary && React.createElement('div', { key: 'bills', className: 'card' }, [
        React.createElement('h3', { key: 'label' }, 'Bills Today'),
        React.createElement('div', { key: 'value', className: 'value' }, todaysSummary.billCount)
      ]),
      summary && React.createElement('div', { key: 'week', className: 'card' }, [
        React.createElement('h3', { key: 'label' }, 'Weekly Sales'),
        React.createElement('div', { key: 'value', className: 'value' }, `₹${summary.totals.totalSales.toFixed(2)}`)
      ]),
      summary && React.createElement('div', { key: 'profit', className: 'card' }, [
        React.createElement('h3', { key: 'label' }, 'Weekly Profit'),
        React.createElement('div', { key: 'value', className: 'value' }, `₹${summary.totals.totalProfit.toFixed(2)}`)
      ])
    ]),
    todaysSummary && todaysSummary.topProducts.length > 0 && React.createElement('div', { key: 'top-products', className: 'section' }, [
      React.createElement('h3', { key: 'title' }, 'Top Products Today'),
      React.createElement('table', { key: 'table' }, [
        React.createElement('thead', { key: 'head' }, React.createElement('tr', null, [
          React.createElement('th', { key: 'name' }, 'Product'),
          React.createElement('th', { key: 'qty' }, 'Quantity Sold'),
          React.createElement('th', { key: 'revenue' }, 'Revenue')
        ])),
        React.createElement('tbody', { key: 'body' }, todaysSummary.topProducts.map(item => 
          React.createElement('tr', { key: item.product.id }, [
            React.createElement('td', { key: 'name' }, item.product.name),
            React.createElement('td', { key: 'qty' }, item.quantity),
            React.createElement('td', { key: 'revenue' }, `₹${item.revenue.toFixed(2)}`)
          ])
        ))
      ])
    ])
  ]);
};

// Products Component
const Products = () => {
  const [products, setProducts] = useState([]);
  const [showForm, setShowForm] = useState(false);
  const [formData, setFormData] = useState({ name: '', price: '', cost: '', category: 'tea' });
  const [editingId, setEditingId] = useState(null);
  const { token } = useAuth();

  useEffect(() => {
    fetchProducts();
  }, []);

  const fetchProducts = async () => {
    try {
      const res = await fetch(`${API_URL}/products`, { headers: { Authorization: `Bearer ${token}` } });
      if (res.ok) {
        const data = await res.json();
        setProducts(data);
      }
    } catch (error) {
      console.error('Error fetching products:', error);
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    const method = editingId ? 'PUT' : 'POST';
    const url = editingId ? `${API_URL}/products/${editingId}` : `${API_URL}/products`;

    try {
      const res = await fetch(url, {
        method,
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`
        },
        body: JSON.stringify(formData)
      });

      if (res.ok) {
        setFormData({ name: '', price: '', cost: '', category: 'tea' });
        setShowForm(false);
        setEditingId(null);
        fetchProducts();
      }
    } catch (error) {
      console.error('Error saving product:', error);
    }
  };

  const handleDelete = async (id) => {
    if (window.confirm('Are you sure?')) {
      try {
        const res = await fetch(`${API_URL}/products/${id}`, {
          method: 'DELETE',
          headers: { Authorization: `Bearer ${token}` }
        });
        if (res.ok) {
          fetchProducts();
        }
      } catch (error) {
        console.error('Error deleting product:', error);
      }
    }
  };

  const handleEdit = (product) => {
    setFormData({ name: product.name, price: product.price, cost: product.cost, category: product.category });
    setEditingId(product.id);
    setShowForm(true);
  };

  return React.createElement('div', null, [
    React.createElement('div', { key: 'header', style: { display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '20px' } }, [
      React.createElement('h2', { key: 'title' }, 'Products'),
      React.createElement('button', { key: 'btn', className: 'btn btn-success', onClick: () => { setShowForm(true); setEditingId(null); setFormData({ name: '', price: '', cost: '', category: 'tea' }); } }, '+ Add Product')
    ]),
    showForm && React.createElement('div', { key: 'form', className: 'modal active' }, React.createElement('div', { className: 'modal-content' }, [
      React.createElement('span', { key: 'close', className: 'close-modal', onClick: () => setShowForm(false) }, '×'),
      React.createElement('h3', { key: 'title' }, editingId ? 'Edit Product' : 'Add Product'),
      React.createElement('form', { key: 'form', onSubmit: handleSubmit }, [
        React.createElement('div', { key: 'name', className: 'form-group' }, [
          React.createElement('label', { key: 'label' }, 'Product Name'),
          React.createElement('input', { key: 'input', type: 'text', value: formData.name, onChange: (e) => setFormData({ ...formData, name: e.target.value }), required: true })
        ]),
        React.createElement('div', { key: 'price', className: 'form-group' }, [
          React.createElement('label', { key: 'label' }, 'Price'),
          React.createElement('input', { key: 'input', type: 'number', value: formData.price, onChange: (e) => setFormData({ ...formData, price: e.target.value }), required: true, step: '0.01' })
        ]),
        React.createElement('div', { key: 'cost', className: 'form-group' }, [
          React.createElement('label', { key: 'label' }, 'Cost Price'),
          React.createElement('input', { key: 'input', type: 'number', value: formData.cost, onChange: (e) => setFormData({ ...formData, cost: e.target.value }), required: true, step: '0.01' })
        ]),
        React.createElement('div', { key: 'category', className: 'form-group' }, [
          React.createElement('label', { key: 'label' }, 'Category'),
          React.createElement('select', { key: 'input', value: formData.category, onChange: (e) => setFormData({ ...formData, category: e.target.value }), style: { width: '100%', padding: '10px', border: '2px solid #e0e0e0', borderRadius: '5px' } }, [
            React.createElement('option', { key: 'tea', value: 'tea' }, 'Tea'),
            React.createElement('option', { key: 'snacks', value: 'snacks' }, 'Snacks'),
            React.createElement('option', { key: 'beverages', value: 'beverages' }, 'Beverages')
          ])
        ]),
        React.createElement('button', { key: 'submit', type: 'submit', className: 'btn-primary' }, 'Save Product')
      ])
    ])),
    React.createElement('table', { key: 'table' }, [
      React.createElement('thead', { key: 'head' }, React.createElement('tr', null, [
        React.createElement('th', { key: 'name' }, 'Name'),
        React.createElement('th', { key: 'price' }, 'Price'),
        React.createElement('th', { key: 'cost' }, 'Cost'),
        React.createElement('th', { key: 'category' }, 'Category'),
        React.createElement('th', { key: 'actions' }, 'Actions')
      ])),
      React.createElement('tbody', { key: 'body' }, products.map(product =>
        React.createElement('tr', { key: product.id }, [
          React.createElement('td', { key: 'name' }, product.name),
          React.createElement('td', { key: 'price' }, `₹${product.price.toFixed(2)}`),
          React.createElement('td', { key: 'cost' }, `₹${product.cost.toFixed(2)}`),
          React.createElement('td', { key: 'category' }, product.category),
          React.createElement('td', { key: 'actions', style: { display: 'flex', gap: '10px' } }, [
            React.createElement('button', { key: 'edit', className: 'btn btn-secondary', onClick: () => handleEdit(product) }, 'Edit'),
            React.createElement('button', { key: 'delete', className: 'btn btn-danger', onClick: () => handleDelete(product.id) }, 'Delete')
          ])
        ])
      ))
    ])
  ]);
};

// Inventory Component
const Inventory = () => {
  const [inventory, setInventory] = useState([]);
  const [lowStock, setLowStock] = useState([]);
  const { token } = useAuth();

  useEffect(() => {
    fetchInventory();
  }, []);

  const fetchInventory = async () => {
    try {
      const res = await fetch(`${API_URL}/inventory`, { headers: { Authorization: `Bearer ${token}` } });
      if (res.ok) {
        const data = await res.json();
        setInventory(data);
        const low = data.filter(item => item.quantity <= item.minLevel);
        setLowStock(low);
      }
    } catch (error) {
      console.error('Error fetching inventory:', error);
    }
  };

  const updateQuantity = async (productId, quantity, type) => {
    try {
      const res = await fetch(`${API_URL}/inventory/${productId}/update`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`
        },
        body: JSON.stringify({ quantity, type })
      });
      if (res.ok) {
        fetchInventory();
      }
    } catch (error) {
      console.error('Error updating inventory:', error);
    }
  };

  return React.createElement('div', null, [
    React.createElement('h2', { key: 'title' }, 'Inventory Management'),
    lowStock.length > 0 && React.createElement('div', { key: 'alerts', className: 'alert alert-warning' }, 
      React.createElement('strong', null, `⚠️ ${lowStock.length} product(s) below minimum stock level`)
    ),
    React.createElement('table', { key: 'table' }, [
      React.createElement('thead', { key: 'head' }, React.createElement('tr', null, [
        React.createElement('th', { key: 'product' }, 'Product'),
        React.createElement('th', { key: 'quantity' }, 'Quantity'),
        React.createElement('th', { key: 'minLevel' }, 'Min Level'),
        React.createElement('th', { key: 'maxLevel' }, 'Max Level'),
        React.createElement('th', { key: 'status' }, 'Status'),
        React.createElement('th', { key: 'actions' }, 'Actions')
      ])),
      React.createElement('tbody', { key: 'body' }, inventory.map(item =>
        React.createElement('tr', { key: item.id }, [
          React.createElement('td', { key: 'product' }, item.product.name),
          React.createElement('td', { key: 'quantity' }, item.quantity),
          React.createElement('td', { key: 'minLevel' }, item.minLevel),
          React.createElement('td', { key: 'maxLevel' }, item.maxLevel),
          React.createElement('td', { key: 'status' }, 
            React.createElement('span', { className: item.quantity <= item.minLevel ? 'badge badge-warning' : 'badge badge-success' }, 
              item.quantity <= item.minLevel ? 'Low Stock' : 'OK'
            )
          ),
          React.createElement('td', { key: 'actions', style: { display: 'flex', gap: '5px' } }, [
            React.createElement('button', { key: 'add', className: 'btn btn-success', onClick: () => updateQuantity(item.productId, 10, 'add') }, '+10'),
            React.createElement('button', { key: 'subtract', className: 'btn btn-danger', onClick: () => updateQuantity(item.productId, 5, 'subtract') }, '-5')
          ])
        ])
      ))
    ])
  ]);
};

// Bills Component
const Bills = () => {
  const [products, setProducts] = useState([]);
  const [bills, setBills] = useState([]);
  const [cart, setCart] = useState([]);
  const [showBillForm, setShowBillForm] = useState(false);
  const [discount, setDiscount] = useState(0);
  const [tax, setTax] = useState(0);
  const [paymentMethod, setPaymentMethod] = useState('cash');
  const { token } = useAuth();

  useEffect(() => {
    fetchProducts();
    fetchBills();
  }, []);

  const fetchProducts = async () => {
    try {
      const res = await fetch(`${API_URL}/products`, { headers: { Authorization: `Bearer ${token}` } });
      if (res.ok) {
        const data = await res.json();
        setProducts(data);
      }
    } catch (error) {
      console.error('Error fetching products:', error);
    }
  };

  const fetchBills = async () => {
    try {
      const res = await fetch(`${API_URL}/bills`, { headers: { Authorization: `Bearer ${token}` } });
      if (res.ok) {
        const data = await res.json();
        setBills(data);
      }
    } catch (error) {
      console.error('Error fetching bills:', error);
    }
  };

  const addToCart = (product) => {
    const existing = cart.find(item => item.productId === product.id);
    if (existing) {
      setCart(cart.map(item => item.productId === product.id ? { ...item, quantity: item.quantity + 1 } : item));
    } else {
      setCart([...cart, { productId: product.id, quantity: 1, name: product.name, price: product.price }]);
    }
  };

  const removeFromCart = (productId) => {
    setCart(cart.filter(item => item.productId !== productId));
  };

  const updateCartQuantity = (productId, quantity) => {
    if (quantity <= 0) {
      removeFromCart(productId);
    } else {
      setCart(cart.map(item => item.productId === productId ? { ...item, quantity } : item));
    }
  };

  const totalAmount = cart.reduce((sum, item) => sum + (item.price * item.quantity), 0);
  const finalAmount = totalAmount - discount + tax;

  const createBill = async () => {
    try {
      const res = await fetch(`${API_URL}/bills`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`
        },
        body: JSON.stringify({
          items: cart,
          discount,
          tax,
          paymentMethod
        })
      });
      if (res.ok) {
        setCart([]);
        setDiscount(0);
        setTax(0);
        setShowBillForm(false);
        fetchBills();
        alert('Bill created successfully!');
      }
    } catch (error) {
      console.error('Error creating bill:', error);
    }
  };

  return React.createElement('div', null, [
    React.createElement('div', { key: 'header', style: { display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '20px' } }, [
      React.createElement('h2', { key: 'title' }, 'Billing'),
      React.createElement('button', { key: 'btn', className: 'btn btn-success', onClick: () => setShowBillForm(!showBillForm) }, showBillForm ? 'Cancel' : 'New Bill')
    ]),
    showBillForm && React.createElement('div', { key: 'form-section', className: 'section' }, [
      React.createElement('h3', { key: 'title' }, 'Create Bill'),
      React.createElement('div', { key: 'products', style: { marginBottom: '20px' } }, [
        React.createElement('h4', { key: 'label' }, 'Select Products:'),
        React.createElement('div', { key: 'list', style: { display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(200px, 1fr))', gap: '10px', marginBottom: '20px' } },
          products.map(product =>
            React.createElement('button', {
              key: product.id,
              onClick: () => addToCart(product),
              style: { padding: '15px', background: '#f0f0f0', border: '2px solid #e0e0e0', borderRadius: '5px', cursor: 'pointer', textAlign: 'left' }
            }, [
              React.createElement('div', { key: 'name', style: { fontWeight: 'bold' } }, product.name),
              React.createElement('div', { key: 'price' }, `₹${product.price.toFixed(2)}`)
            ])
          )
        )
      ]),
      cart.length > 0 && React.createElement('div', { key: 'cart' }, [
        React.createElement('h4', { key: 'title' }, 'Cart Items:'),
        React.createElement('table', { key: 'table' }, [
          React.createElement('thead', { key: 'head' }, React.createElement('tr', null, [
            React.createElement('th', { key: 'name' }, 'Product'),
            React.createElement('th', { key: 'price' }, 'Price'),
            React.createElement('th', { key: 'qty' }, 'Qty'),
            React.createElement('th', { key: 'total' }, 'Total'),
            React.createElement('th', { key: 'action' }, 'Action')
          ])),
          React.createElement('tbody', { key: 'body' }, cart.map(item =>
            React.createElement('tr', { key: item.productId }, [
              React.createElement('td', { key: 'name' }, item.name),
              React.createElement('td', { key: 'price' }, `₹${item.price.toFixed(2)}`),
              React.createElement('td', { key: 'qty' }, React.createElement('input', { type: 'number', value: item.quantity, onChange: (e) => updateCartQuantity(item.productId, parseInt(e.target.value)), style: { width: '50px' } })),
              React.createElement('td', { key: 'total' }, `₹${(item.price * item.quantity).toFixed(2)}`),
              React.createElement('td', { key: 'action' }, React.createElement('button', { className: 'btn btn-danger', onClick: () => removeFromCart(item.productId) }, 'Remove'))
            ])
          ))
        ]),
        React.createElement('div', { key: 'summary', style: { marginTop: '20px', padding: '15px', background: '#f9fafb', borderRadius: '5px' } }, [
          React.createElement('div', { key: 'total', style: { marginBottom: '10px' } }, `Subtotal: ₹${totalAmount.toFixed(2)}`),
          React.createElement('div', { key: 'discount-input', className: 'form-group' }, [
            React.createElement('label', { key: 'label' }, 'Discount:'),
            React.createElement('input', { key: 'input', type: 'number', value: discount, onChange: (e) => setDiscount(parseFloat(e.target.value)), step: '0.01' })
          ]),
          React.createElement('div', { key: 'tax-input', className: 'form-group' }, [
            React.createElement('label', { key: 'label' }, 'Tax:'),
            React.createElement('input', { key: 'input', type: 'number', value: tax, onChange: (e) => setTax(parseFloat(e.target.value)), step: '0.01' })
          ]),
          React.createElement('div', { key: 'payment', className: 'form-group' }, [
            React.createElement('label', { key: 'label' }, 'Payment Method:'),
            React.createElement('select', { key: 'select', value: paymentMethod, onChange: (e) => setPaymentMethod(e.target.value), style: { width: '100%', padding: '10px', border: '2px solid #e0e0e0', borderRadius: '5px' } }, [
              React.createElement('option', { key: 'cash', value: 'cash' }, 'Cash'),
              React.createElement('option', { key: 'card', value: 'card' }, 'Card'),
              React.createElement('option', { key: 'upi', value: 'upi' }, 'UPI')
            ])
          ]),
          React.createElement('div', { key: 'final', style: { fontSize: '20px', fontWeight: 'bold', marginTop: '10px', color: '#667eea' } }, `Final Amount: ₹${finalAmount.toFixed(2)}`),
          React.createElement('button', { key: 'submit', className: 'btn-primary', onClick: createBill, style: { marginTop: '10px' } }, 'Create Bill')
        ])
      ])
    ]),
    React.createElement('h3', { key: 'history-title' }, 'Recent Bills'),
    React.createElement('table', { key: 'table' }, [
      React.createElement('thead', { key: 'head' }, React.createElement('tr', null, [
        React.createElement('th', { key: 'billno' }, 'Bill No'),
        React.createElement('th', { key: 'total' }, 'Total'),
        React.createElement('th', { key: 'method' }, 'Payment Method'),
        React.createElement('th', { key: 'date' }, 'Date')
      ])),
      React.createElement('tbody', { key: 'body' }, bills.slice(0, 10).map(bill =>
        React.createElement('tr', { key: bill.id }, [
          React.createElement('td', { key: 'billno' }, bill.billNo),
          React.createElement('td', { key: 'total' }, `₹${bill.finalAmount.toFixed(2)}`),
          React.createElement('td', { key: 'method' }, bill.paymentMethod),
          React.createElement('td', { key: 'date' }, new Date(bill.createdAt).toLocaleDateString())
        ])
      ))
    ])
  ]);
};

// Main App Component
const App = () => {
  const { isAuthenticated, logout, user } = useAuth();
  const [currentPage, setCurrentPage] = useState('dashboard');

  if (!isAuthenticated) {
    return React.createElement(Login);
  }

  const renderPage = () => {
    switch (currentPage) {
      case 'dashboard':
        return React.createElement(Dashboard);
      case 'products':
        return React.createElement(Products);
      case 'inventory':
        return React.createElement(Inventory);
      case 'bills':
        return React.createElement(Bills);
      default:
        return React.createElement(Dashboard);
    }
  };

  return React.createElement('div', null, [
    React.createElement('div', { key: 'header', className: 'header' }, [
      React.createElement('h1', { key: 'title' }, '🍵 Tea Shop Billing'),
      React.createElement('div', { key: 'nav', className: 'nav-links' }, [
        React.createElement('button', { key: 'dashboard', onClick: () => setCurrentPage('dashboard'), style: { background: currentPage === 'dashboard' ? '#764ba2' : '#667eea' } }, 'Dashboard'),
        React.createElement('button', { key: 'products', onClick: () => setCurrentPage('products'), style: { background: currentPage === 'products' ? '#764ba2' : '#667eea' } }, 'Products'),
        React.createElement('button', { key: 'inventory', onClick: () => setCurrentPage('inventory'), style: { background: currentPage === 'inventory' ? '#764ba2' : '#667eea' } }, 'Inventory'),
        React.createElement('button', { key: 'bills', onClick: () => setCurrentPage('bills'), style: { background: currentPage === 'bills' ? '#764ba2' : '#667eea' } }, 'Billing'),
        React.createElement('button', { key: 'logout', onClick: logout, style: { background: '#ef4444' } }, `Logout (${user?.name || 'User'})`)
      ])
    ]),
    React.createElement('div', { key: 'container', className: 'container' }, React.createElement('div', { className: 'content' }, renderPage()))
  ]);
};

// Render the app
ReactDOM.render(
  React.createElement(AuthProvider, null, React.createElement(App)),
  document.getElementById('root')
);
